# Copyright 2021 Yi Tseng
# SPDX-License-Identifier: Apache-2.0

from p4runtime_sh.shell import main
main()  # pragma: no cover
